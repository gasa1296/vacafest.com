$(document).ready(function (){
    
    cargaCompleta();

    $("#postulate").click(function () {
        boton_2 ();
    });

    $("#boton-1").click(function () {
        boton_1();
    })

    $("#boton-2").click(function () {
        boton_2();
    });

    $("#boton-3").click(function () {
        boton_3();
    });

})

function cargaCompleta () {
    setTimeout(function(){
        $("#presentacion").css("display", "block");
        $("#circulo_amarillo").css("display", "block");
        $("#video-presentacion").css("display", "block");
        $("#fecha-pag-1").css("display", "block");
        $("#postulate").css("display", "block");
        $("#viva_la_vaca").css("display", "block");

        $("#quinta_edicion").addClass("animated slideBorder");
        $("#circulo_amarillo").addClass("animated zoomIn");
        $("#presentacion").addClass("animated slideInUp");
        $("#video-presentacion").addClass("animated fadeInUp");
        $("#fecha-pag-1").addClass("animated fadeInUp");
        $("#postulate").addClass("animated fadeInUp");
        $("#viva_la_vaca").addClass("animated fadeInLeft");
    }, 2000);
}

function boton_1 (){
    if ($("#form").css("display") == "block"){
        $("#presentacion").removeClass();
        $("#form").removeClass();
        $("#viva_la_vaca").removeClass();
        $("#circulo_amarillo").removeClass();
        $("#quinta_edicion").removeClass();

        $("#form").addClass("col-lg-11 vh-75 animated slideOutRight");
        $("#presentacion").addClass("col-lg-9 vh-75 animated slideInLeft");
        $("#viva_la_vaca").addClass("animated slideInLeft");
        $("#circulo_amarillo").addClass("animated slideLeftBorderToCenter");
        $("#quinta_edicion").addClass("animated slideInLeft");

        $("#form").css("display", "none");
        $("#presentacion").css("display", "block");
        $("#quinta_edicion").css("display", "block");
    }
    else if ($("#rrss").css("display") == "block"){
        $("#quinta_edicion").css("right", "79vw");
        $("#quinta_edicion").css("top", "39.5vh");
        $("#quinta_edicion").css("height", "21vh");
        $("#quinta_edicion").css("width", "21vw");

        $("#presentacion").removeClass();
        $("#rrss").removeClass();
        $("#viva_la_vaca").removeClass();
        $("#circulo_amarillo").removeClass();
        $("#quinta_edicion").removeClass();

        $("#rrss").addClass("col-lg-12 vh-100 animated slideOutLeft");
        $("#presentacion").addClass("col-lg-9 vh-75 animated slideInRight");
        $("#viva_la_vaca").addClass("animated slideInRight");
        $("#circulo_amarillo").addClass("animated slideRightBorderToCenter");
        $("#quinta_edicion").addClass("animated slideInRight");

        $("#rrss").css("display", "none");
        $("#quinta_edicion").css("display", "block");
        $("#viva_la_vaca").css("display", "block");
        $("#presentacion").css("display", "block");
    }
}

function boton_2 (){
    if ($("#presentacion").css("display") == "block") {
        $("#quinta_edicion").css("right", "79vw");
        $("#quinta_edicion").css("top", "39.5vh");
        $("#quinta_edicion").css("height", "21vh");
        $("#quinta_edicion").css("width", "21vw");

        $("#presentacion").removeClass();
        $("#form").removeClass();
        $("#circulo_amarillo").removeClass();
        $("#viva_la_vaca").removeClass();
        $("#quinta_edicion").removeClass();

        $("#presentacion").addClass("col-lg-9 vh-75 animated slideOutLeft");
        $("#form").addClass("col-lg-11 vh-75 animated slideInRight");
        $("#circulo_amarillo").addClass("animated slideBorderLeft");
        $("#viva_la_vaca").addClass("animated slideRightToLeft");
        $("#quinta_edicion").addClass("animated slideBorder");

        $("#presentacion").css("display", "none");
        $("#quinta_edicion").css("display", "none");
        $("#form").css("display", "block");
    }
    else if ($("#rrss").css("display") == "block") {
        $("#rrss").removeClass();
        $("#form").removeClass();

        $("#rrss").addClass("col-lg-12 vh-100 animated slideOutRight");
        $("#form").addClass("col-lg-9 vh-75 animated slideInLeft");

        $("#rrss").css("display", "none");
        $("#form").css("display", "block");
    }
}

function boton_3 (){
    if ($("#form").css("display") == "block") {
        $("#rrss").removeClass();
        $("#form").removeClass();
        $("#viva_la_vaca").removeClass();
        $("#circulo_amarillo").removeClass();

        $("#form").addClass("col-lg-9 vh-75 animated slideOutLeft");
        $("#rrss").addClass("col-lg-12 vh-100 animated slideInRight");
        $("#viva_la_vaca").addClass("animated slideLeftOut");
        $("#circulo_amarillo").addClass("animated slideLeftBorderOut");
        setTimeout(() =>{
            $("#circulo_amarillo").removeClass();
            $("#circulo_amarillo").addClass("animated slideRightIn");
        },1000);

        $("#form").css("display", "none");
        $("#viva_la_vaca").css("display", "none");
        $("#rrss").css("display", "block");
    }
    else if ($("#presentacion").css("display") == "block") {
        $("#presentacion").removeClass();
        $("#rrss").removeClass();
        $("#viva_la_vaca").removeClass();
        $("#circulo_amarillo").removeClass();
        $("#quinta_edicion").removeClass();

        $("#presentacion").addClass("col-lg-9 vh-75 animated slideOutRight");
        $("#quinta_edicion").addClass("animated slideOutRight");
        $("#viva_la_vaca").addClass("animated slideOutLeft");
        $("#rrss").addClass("col-lg-12 vh-100 animated slideInLeft");
        $("#circulo_amarillo").addClass("animated slideBorderRight");

        $("#presentacion").css("display", "none");
        $("#quinta_edicion").css("display", "none");
        $("#viva_la_vaca").css("display", "none");
        $("#rrss").css("display", "block");
    }
}